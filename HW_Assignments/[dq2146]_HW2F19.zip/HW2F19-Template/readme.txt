App are mainly in charge of the string parse and routing( based on flask)
/src/data_service/data_table_adaptor.py maintains all the RDBDataTable the user has visited
/src/data_service/RDBDataTable.py is where the service interact with databases it used the template we built in HW1